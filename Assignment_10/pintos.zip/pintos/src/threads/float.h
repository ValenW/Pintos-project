#define FLOAT (1 << 14)
#define INT_MIN (-(1 << 31))
#define INT_MAX ((1 << 31) - 1)

int int_to_fp(int n);
int fp_to_int_round(int x);
int fp_to_int(int x);
int fp_add(int x, int y);
int fp_sub(int x, int y);
int fp_add_int(int x, int n);
int fp_sub_int(int x, int n);
int fp_mult(int x, int y);
int fp_div(int x, int y);
int fp_mult_int(int x, int y);
int fp_div_int(int x, int n);

int int_to_fp(int n) {
    return n*FLOAT;
}

int fp_to_int_round(int x) {
    return x >= 0 ? (x + FLOAT/2)/FLOAT : (x - FLOAT/2)/FLOAT;
}

int fp_to_int(int x) {
    return x/FLOAT;
}

int fp_add(int x, int y) {
    return x + y;
}

int fp_sub(int x, int y) {
    return x - y;
}

int fp_add_int(int x, int n) {
    return x + (n*FLOAT);
}

int fp_sub_int(int x, int n) {
    return x - (n*FLOAT);
}

int fp_mult(int x, int y) {
    return ((int64_t) x) * y / FLOAT;
}

int fp_div(int x, int y) {
    return ((int64_t) x) * FLOAT /y;
}

int fp_mult_int(int x, int n) {
    return x * n;
}

int fp_div_int(int x, int n) {
    return  x / n;
}
