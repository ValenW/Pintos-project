#include "vm/frame.h"
#include "vm/swap.h"
#include "userprog/syscall.h"
#include "userprog/pagedir.h"
#include "filesys/file.h"
#include "threads/malloc.h"
static struct lock frame_table_lock;
static struct list frame_table;

void *frame_alloc_evict (enum palloc_flags flags);

void 
frame_alloc_init (void) {
  lock_init (&frame_table_lock);
  list_init (&frame_table);
}

void*
frame_alloc_get_page (enum palloc_flags flags, struct page *uvpage) {
  if (!(flags & PAL_USER)) //these frame should be used ONLY in user prog
    return NULL;
  void *kpage = palloc_get_page (flags);
  if (kpage == NULL) {
    /* else evict a frame from frame table */
    kpage = frame_alloc_evict (flags);
    if (kpage == NULL)
      PANIC ("Not enough spaces for allocating a free frame.");
  }
   /* Add a frame to frame table */
  struct frame *f = (struct frame *)malloc (sizeof (struct frame));
  f->kpage = kpage;
  f->used_process = thread_current ();
  f->uvpage = uvpage;
  lock_acquire (&frame_table_lock);
  list_push_back (&frame_table, &f->elem);
  lock_release (&frame_table_lock);
  return f->kpage;
}

void 
frame_free_page (void *kpage) {
  struct list_elem *e;
  /* Scan the frame table to find an elem for KPAGE */
  lock_acquire (&frame_table_lock);
  for (e = list_begin (&frame_table); e != list_end (&frame_table); e = list_next (e)) {
    struct frame *f = list_entry (e, struct frame, elem);
    if (f->kpage == kpage) {
      list_remove (e); //remove elem from the table
      palloc_free_page (kpage); //free the page to user pool
      free (f); //free the block memory
      break;
    }
  }
  lock_release (&frame_table_lock);
}

/* Free a frame in frame table. Write back to Swap Space or File SYS corresponding to the 
   UVPAGE of that frame.*/
void*
frame_alloc_evict (enum palloc_flags flags) {

}
